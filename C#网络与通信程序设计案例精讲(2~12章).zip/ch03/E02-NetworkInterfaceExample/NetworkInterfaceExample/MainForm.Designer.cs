﻿namespace NetworkInterfaceExample
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxAdpterInfo = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // listBoxAdpterInfo
            // 
            this.listBoxAdpterInfo.FormattingEnabled = true;
            this.listBoxAdpterInfo.ItemHeight = 12;
            this.listBoxAdpterInfo.Location = new System.Drawing.Point(12, 24);
            this.listBoxAdpterInfo.Name = "listBoxAdpterInfo";
            this.listBoxAdpterInfo.Size = new System.Drawing.Size(325, 208);
            this.listBoxAdpterInfo.TabIndex = 0;
            // 
            // FormAdpterInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 261);
            this.Controls.Add(this.listBoxAdpterInfo);
            this.Name = "FormAdpterInfo";
            this.Text = "网络适配器信息";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxAdpterInfo;
    }
}

