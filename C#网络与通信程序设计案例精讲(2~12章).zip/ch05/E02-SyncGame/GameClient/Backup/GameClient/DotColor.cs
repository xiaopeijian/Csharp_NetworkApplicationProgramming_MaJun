//----------DotColor.cs---------------//
namespace GameClient
{
    public enum DotColor
    {
        /// <summary>
        /// ������
        /// </summary>
        None = -1,
        /// <summary>
        /// ��ɫ����
        /// </summary>
        Black = 0,
        /// <summary>
        /// ��ɫ����
        /// </summary>
        White = 1
    }
}
